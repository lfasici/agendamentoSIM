import { type AvailableSlot, type InsertAvailableSlot, type Appointment, type InsertAppointment } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Available slots
  getAvailableSlots(): Promise<AvailableSlot[]>;
  getAvailableSlotsByDate(date: string): Promise<AvailableSlot[]>;
  createAvailableSlot(slot: InsertAvailableSlot): Promise<AvailableSlot>;
  updateAvailableSlot(id: string, updates: Partial<AvailableSlot>): Promise<AvailableSlot | undefined>;
  deleteAvailableSlot(id: string): Promise<boolean>;

  // Appointments
  getAppointments(): Promise<Appointment[]>;
  getAppointmentsByEmail(email: string): Promise<Appointment[]>;
  getAppointmentsByDateRange(startDate: string, endDate: string): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: string, updates: Partial<Appointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: string): Promise<boolean>;
  getAppointmentByCode(code: string): Promise<Appointment | undefined>;
}

export class MemStorage implements IStorage {
  private availableSlots: Map<string, AvailableSlot>;
  private appointments: Map<string, Appointment>;

  constructor() {
    this.availableSlots = new Map();
    this.appointments = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed some available time slots for the next few days
    const today = new Date();
    const slots = [
      { time: "08:00", service: "Carregamento" as const },
      { time: "10:00", service: "Descarregamento" as const },
      { time: "14:00", service: "Carregamento" as const },
      { time: "16:00", service: "Descarregamento" as const },
    ];

    for (let day = 0; day < 7; day++) {
      const date = new Date(today);
      date.setDate(today.getDate() + day);
      
      slots.forEach(({ time, service }) => {
        const [hours, minutes] = time.split(':');
        const slotDate = new Date(date);
        slotDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);
        
        const slot: AvailableSlot = {
          id: randomUUID(),
          dataHora: slotDate.toISOString(),
          servico: service,
          disponivel: true,
          criadoEm: new Date().toISOString(),
        };
        
        this.availableSlots.set(slot.id, slot);
      });
    }
  }

  // Available slots methods
  async getAvailableSlots(): Promise<AvailableSlot[]> {
    return Array.from(this.availableSlots.values());
  }

  async getAvailableSlotsByDate(date: string): Promise<AvailableSlot[]> {
    const targetDate = new Date(date);
    const startOfDay = new Date(targetDate.setHours(0, 0, 0, 0));
    const endOfDay = new Date(targetDate.setHours(23, 59, 59, 999));

    return Array.from(this.availableSlots.values()).filter(slot => {
      const slotDate = new Date(slot.dataHora);
      return slotDate >= startOfDay && slotDate <= endOfDay;
    });
  }

  async createAvailableSlot(insertSlot: InsertAvailableSlot): Promise<AvailableSlot> {
    const id = randomUUID();
    const slot: AvailableSlot = {
      ...insertSlot,
      id,
      criadoEm: new Date().toISOString(),
    };
    this.availableSlots.set(id, slot);
    return slot;
  }

  async updateAvailableSlot(id: string, updates: Partial<AvailableSlot>): Promise<AvailableSlot | undefined> {
    const existing = this.availableSlots.get(id);
    if (!existing) return undefined;

    const updated = { ...existing, ...updates };
    this.availableSlots.set(id, updated);
    return updated;
  }

  async deleteAvailableSlot(id: string): Promise<boolean> {
    return this.availableSlots.delete(id);
  }

  // Appointments methods
  async getAppointments(): Promise<Appointment[]> {
    return Array.from(this.appointments.values());
  }

  async getAppointmentsByEmail(email: string): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      appointment => appointment.emailCliente === email
    );
  }

  async getAppointmentsByDateRange(startDate: string, endDate: string): Promise<Appointment[]> {
    const start = new Date(startDate);
    const end = new Date(endDate);

    return Array.from(this.appointments.values()).filter(appointment => {
      const appointmentDate = new Date(appointment.dataHora);
      return appointmentDate >= start && appointmentDate <= end;
    });
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = randomUUID();
    const codigoConfirmacao = Math.random().toString(36).substr(2, 8).toUpperCase();
    
    const appointment: Appointment = {
      ...insertAppointment,
      id,
      codigoConfirmacao,
      criadoEm: new Date().toISOString(),
    };
    
    this.appointments.set(id, appointment);
    return appointment;
  }

  async updateAppointment(id: string, updates: Partial<Appointment>): Promise<Appointment | undefined> {
    const existing = this.appointments.get(id);
    if (!existing) return undefined;

    const updated = { ...existing, ...updates };
    this.appointments.set(id, updated);
    return updated;
  }

  async deleteAppointment(id: string): Promise<boolean> {
    return this.appointments.delete(id);
  }

  async getAppointmentByCode(code: string): Promise<Appointment | undefined> {
    return Array.from(this.appointments.values()).find(
      appointment => appointment.codigoConfirmacao === code
    );
  }
}

export const storage = new MemStorage();
